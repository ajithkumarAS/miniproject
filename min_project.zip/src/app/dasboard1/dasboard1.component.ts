import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dasboard1',
  templateUrl: './dasboard1.component.html',
  styleUrls: ['./dasboard1.component.css']
})
export class Dasboard1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
